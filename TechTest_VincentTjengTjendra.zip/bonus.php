<!-- <style>
.vertical-center {
  margin: 0;
  position: absolute;
  top: 30%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
</style> -->

<h1>Login</h1>
<div class="textbox">
    <input type="text" id="email" name="mail" placeholder="Email">
</div>
<div class="textbox">
<input type="password" id="password" name="pwd" placeholder="Password">
</div>

<p>Belum memiliki akun ?</p>
<a href="signup.php" >Daftar di sini</a>

<div class="vertical-center">
    <button onclick="signIn()" id="signIn" class="btn btn-outline-primary" type="submit" name="login-submit" >Login</button>
</div>