<html>
    <main>
        <div class="login-box">
            <h1>Sign Up</h1>
                <div class="textbox">
                    <input type="text" name="mail" id="email" placeholder="Email">
                </div>
                <div class="textbox">
                    <input type="password" name="pwd" id="password" placeholder="Password">
                </div>
                <div class="textbox">
                    <input type="password" name="pwd2" placeholder="Ulangi Password">
                </div>
            <button onclick="signUp()" id="signUp" class="btn btn-outline-primary">Sign Up</button>
            <!-- </form> -->
            <p>Sudah memiliki akun ?</p>
            <a href="bonus.php">Login di sini</a>
        </div>
    </main>
</html>