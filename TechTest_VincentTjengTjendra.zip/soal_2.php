<?php

    $result = mysql_query("SELECT mhs_id FROM tb_mahasiswa_nilai WHERE mk_id = '2' ORDER BY nilai DESC LIMIT 1");
    $row = mysql_fetch_row($result);
    $id = $row[0];

    $result2 = mysql_query("SELECT mhs_nama FROM tb_mahasiswa WHERE mhs_id = '$id'");
    $row2 = mysql_fetch_row($result2);
    $nama = $row2[0];

    echo $nama;
?>