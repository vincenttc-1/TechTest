<?php
    
    function divide() {
        $quotient = 0;
        $x = 21;
        $y = 7;

        while ($x >= $y) {
            $x = $x - $y;
            $quotient++;
        }
        echo $quotient;
    }

    divide();

?>