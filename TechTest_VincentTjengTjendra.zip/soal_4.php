<?php

    $x = 1;
    $y = 50;
    $word1 = 'Foo';
    $word2 = 'Bar';
    $word3 = 'FooBar';

    while($x<=$y) {
        if($x%3==0 && $x%5==0){
            echo $word3;
        }
        else if($x%3==0){
            echo $word1;
        }
        else if($x%5==0){
            echo $word2;
        }
        else{
            echo $x;
        }
        $x++;
        ?>
        <br>
        <?php
    }

?>